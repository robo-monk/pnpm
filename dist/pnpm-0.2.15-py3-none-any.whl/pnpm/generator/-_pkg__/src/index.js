export function -__pkg__Test(){
    console.log("hello from -__pkg__")
}