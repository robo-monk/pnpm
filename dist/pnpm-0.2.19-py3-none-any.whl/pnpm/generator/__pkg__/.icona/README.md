# ICONA
convert a folder containing svgs to a json file for use with pragmajs


# How to use:

### Prerequisites
- Python 3
- A folder with svgs


```bash
$ git clone git@github.com:robo-monk/ICONA.git
$ cd ICONA

$ ./icona [/DIRECTORY/NAME] (without the brackets)
```
