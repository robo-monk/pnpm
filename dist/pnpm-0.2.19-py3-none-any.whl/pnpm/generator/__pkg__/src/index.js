export function __pkg__Test(){
    console.log("hello from ___pkg__")
}