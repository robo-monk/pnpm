module.exports = {
    verbose: true
}
