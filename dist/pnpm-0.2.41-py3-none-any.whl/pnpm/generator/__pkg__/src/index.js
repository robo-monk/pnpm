export * from "./.build_assets/index" // globalifies pragmajs, exports packages assets

export function __pkg__Test(){
    console.log("hello from ___pkg__")
}